# 二维 DMD：名义 CD 工作点与相对曝光量检查

本程序沿用“微镜状态 → 有效复振幅 → 相干投影 → 强度与阈值边缘”链路。本轮在已有 ON/OFF 漏光模型上，增加一次性的名义 CD 工作点设定和小范围曝光量扰动检查。参数均为演示值，结果是**空中像阈值宽度**，尚未经过真实材料与工艺校准。

## 运行与修改参数

建议 Python 3.10 或以上，仅依赖 NumPy、Matplotlib。解压后在代码目录运行：

```bash
python -m pip install -r requirements.txt
python run_dmd_2d_validation.py
python run_dmd_2d_validation.py --show
python run_dmd_2d_validation.py --output-dir my_results
```

PyCharm 可直接运行 `run_dmd_2d_validation.py`。默认输出到当前工作目录下的 `dmd_2d_validation_results/`；随包的实际运行结果在 `results/`。`--show` 需本机图形环境，本次自动验证使用无界面的 Agg 后端。

常用参数集中在入口底部的 `main()`，按开关、几何光学、双态响应、评价设置排列：

| 参数或开关 | 默认值与作用 |
|---|---|
| `threshold_mode` | `"target_cd"`，以现有 `on_width_um` 为目标 CD；可改为 `"fixed_fraction"` |
| `threshold_fraction` | `0.5`，供兼容模式及原峰值相对阈值辅助对照使用 |
| `run_leakage_sweep` | `True`，eta=1、phi=0，扫描 rho=(0, 1e-4, 1e-3, 1e-2) |
| `run_phase_sweep` | `True`，eta=1、rho=0.01，对照 phi=(0, π/2, π) |
| `run_dose_check` | `True`，只比较响应基准与集中参数区中的一个代表响应 |
| `dose_scales` | `(0.95, 1.0, 1.05)`，相对名义曝光量 s=E/E0 |
| `run_textbook_validation`、`run_na_experiment`、`run_sampling_experiment` | 原教材、NA、采样比实验，默认均为 `False` |
| `run_original_cross`、`run_convergence`、`run_cross_leakage` | 原十字、原收敛检查、可选十字漏光对照，默认均为 `False` |

默认周期图形为 ON 宽 6 μm、周期 12 μm；投影像元间距 1.5 μm、波长 0.405 μm、像方 NA=0.065、64×32 微镜、16 点/微镜、有效开口边长比 0.95。新周期实验要求窗口含整数周期、每周期含整数像元。原实验参数保持不变，包括采样比 `(3.5, 2.0, 1.0)` 及其几何偏移。

开关同时控制计算、绘图与保存，关闭项在摘要中为 `NOT RUN`；基础自检始终执行。只开曝光量检查或只开相位对照也会自行建立所需基准。重复使用输出目录时不会删除旧文件；请以摘要中的“本次生成文件”为准，也可每次指定新目录。

## 名义工作点与曝光量约定

同一周期参考组用相同几何、有限开口和光学配置，在 eta=1、rho=0、s=1 时建立基准。`reference_intensity` 是固定评价区域内的基准峰值，只计算一次。

| 模式 | 名义阈值 T0 的确定方法 |
|---|---|
| `target_cd`（main 默认） | 在设计左右边缘进行分段线性插值；确认强度对称，再确定 T0，并用原受限阈值测量确认基准 CD 达到 `on_width_um` |
| `fixed_fraction` | T0=`threshold_fraction × reference_intensity`，保留上一版固定比例行为 |

目标模式只支持本轮的中心对称周期基准。明显不对称、无有效双边缘、设计边缘越界或目标宽度无法满足时会明确报错，不自动退回 0.5。函数接口仍以 `fixed_fraction` 为兼容默认，由 `main()` 显式选择 `target_cd`。

默认实际计算得到：`T0=0.20382631104900517`、`I_ref=1.0546765820801907`、`T0/I_ref=0.19325953995014`，名义基准 CD 为 6 μm。这些数值由数据计算，并非写入算法的常量。改用 `fixed_fraction=0.5` 时，基准 CD 约 4.099148 μm；rho=0.01、phi=0 的 CD 约 4.245460 μm。

T0 确定后，响应扫描均使用 s=1 和同一个 T0，不再逐案例匹配目标 CD。曝光量检查保持原始强度 I、共同 I_ref 与名义 T0 不变，仅使用有效强度阈值：

\[
T(s)=T_0/s,\qquad s=E/E_0>0.
\]

这等价于把曝光量分布乘 s 后与固定 T0 比较；程序只采用前一种做法。两个响应各计算一次原始光强，三个 s 复用截面，不重复 FFT；已运行的扫描截面也会复用。只改变 s 时，原始强度、设计边缘 NILS 和中心对比度不变，阈值边缘及暗区超阈值判断随 T0/s 改变。

## s 与双态响应的区别

响应转换与传播沿用原实现：

\[
A_{\rm on}=\sqrt{\eta},\qquad A_{\rm off}=\sqrt{\eta\rho}\,e^{i\phi},\qquad
I=|\mathcal H(A_{\rm on}G_{\rm on}+A_{\rm off}G_{\rm off})|^2.
\]

| 参数 | 含义 |
|---|---|
| `on_intensity_scale`：eta≥0 | ON 相对于模型参考的等效强度缩放，作用于输入场；不是曝光倍率 s，也不是器件总效率 |
| `off_to_on_intensity_ratio`：0≤rho≤1 | 双态等效强度比，转为场时开平方；不能直接套用混合图形暗亮中心强度比 |
| `off_relative_phase_rad`：phi | OFF 相对 ON 的光学相位，单位 rad；与几何位置 `phase_offset_um` 不同 |
| `dose_scale`：s>0 | 相对名义曝光量，通过 T0/s 参与评价，不再次缩放 DMD 场或原始强度 |

ON/OFF 系数只作用于原微镜有效开口，镜间隙及亚采样覆盖权重保留。0.95 是开口边长比，理想方形开口面积比例是 0.95²。相干交叉项可正可负，相位对照属于敏感性分析，不代表实际二值 DMD 可以独立控制漏光相位。

## 输出与指标

默认输出 **3 张图、1 份 CSV、1 个 NPZ、1 份摘要**；CSV 含 13 个实验案例：比例扫描 4 个、相位对照 3 个、曝光量检查 6 个。

| 文件 | 内容 |
|---|---|
| `figure_leakage_ratio.png` | 名义 s=1 下的比例扫描、共同强度标尺、T0、CD/边缘变化与设计边缘 NILS |
| `figure_leakage_phase.png` | 名义 s=1 下三种相位的同类对照 |
| `figure_leakage_dose.png` | 基准及代表响应的 CD—相对曝光量曲线与目标 CD 线 |
| `leakage_metrics.csv` | 响应、工作点、s、有效阈值、核心指标、明确参考对象的变化量与有效状态 |
| `leakage_representative_data.npz` | 原始截面、少量代表复场、工作点及曝光量元数据，供复查与重新绘图 |
| `validation_summary.txt` | 实际自检与判据、完整配置、实验状态、结果解释及本次文件清单 |

`fixed_cd_um` 为包含目标中心的超阈值区间宽度。CSV 中 `nominal_threshold_intensity` 始终是 T0，`threshold_intensity` 是当前案例的 T0/s。以下变化量应分别阅读：

| 字段 | 参考对象与公式 |
|---|---|
| `delta_cd_to_nominal_baseline_um` | 总变化：CD(case,s)−CD(baseline,1)，包含响应与曝光量的影响 |
| `delta_cd_to_same_dose_baseline_um` | 同曝光倍率的响应增量：CD(case,s)−CD(baseline,s) |
| `cd_error_to_design_um` | 相对设计宽度：CD(case,s)−on_width_um |

旧 `delta_cd_to_baseline_um` 是总变化的兼容别名；左右边缘变化也以 baseline,s=1 为参考。即使某些数值相同，参考对象的定义仍不同。同剂量基准失效时，增量为 NaN，原因保存于 `same_dose_baseline_status`。NILS 保持原设计右边缘、七点四次局部多项式和绝对值约定；`relative_peak_cd_um` 仅在代表案例提供旧峰值相对阈值辅助对照。

无有效中心区间或双边缘时，阈值 CD 返回 NaN 并记录原因。暗区只检查预先指定的截面中部，默认 x∈[4.5,7.5] μm；CSV 记录实际采样边界，判断使用当前有效阈值。它不是整个二维图形的缺陷检查。

默认 `target_cd` 结果如下，代表响应为 eta=1、rho=0.01、phi=0：

| s | 基准 CD / μm | 代表响应 CD / μm | 同曝光倍率响应增量 / μm |
|---|---:|---:|---:|
| 0.95 | 5.921152325 | 6.245488225 | +0.324335900 |
| 1.00 | 6.000000000 | 6.332466688 | +0.332466688 |
| 1.05 | 6.071338373 | 6.413127293 | +0.341788921 |

可选十字仍使用**独立参考组与原 0.5 比例阈值**，默认关闭；没有把中央臂长当作 6 μm 臂宽匹配，也没有验证十字与周期图形共用工艺工作点。其独立配置为 64×64 微镜、8 点/微镜，比较 96 μm 与 192 μm 视场内的固定中央区域。

## 读取 NPZ 重新绘图

NPZ 用于保留原始数据与复数相位，不需要重新运行光学传播。同一曝光量检查响应不会按每个 s 重复保存截面；`dose_representative_profile_key` 指向实际复用的数组名。下例在代码目录运行，读取随包结果并显示 s=0.95 对应的阈值：

```python
import numpy as np
import matplotlib.pyplot as plt

with np.load("results/leakage_representative_data.npz", allow_pickle=False) as data:
    x = data["x_um"]
    baseline = data["baseline_raw_profile"]
    response_key = str(data["dose_representative_profile_key"].item())
    response = data[response_key]
    reference = float(data["reference_intensity"])
    nominal_threshold = float(data["nominal_threshold_intensity"])
    scale = float(data["dose_scales"][0])

plt.plot(x, baseline / reference, label="Baseline")
plt.plot(x, response / reference, label="Representative response")
plt.axhline(nominal_threshold / scale / reference, color="black",
            linestyle="--", label=f"T0/s, s={scale:g}")
plt.xlim(-6, 6)
plt.xlabel("x (um)")
plt.ylabel("I / common I_ref")
plt.legend()
plt.tight_layout()
plt.show()
```

仅在开启曝光量检查时保存 `dose_*` 元数据。需要检查相位时，可直接读取 `baseline_image_field_center_row` 或 `representative_image_field`，它们保持复数；后者对应的响应由 `representative_case_name` 标识。

## 修改范围与验证

| 文件 | 本轮状态 |
|---|---|
| `run_dmd_2d_validation.py` | 增加名义工作点、曝光量评价、明确的变化量字段及对应调度和输出 |
| `test_leakage_validation.py` | 扩展现有数值验证；是主程序运行依赖，必须留在代码根目录，不能移入 `verification/` |
| `README.md` | 更新运行、工作点、数据读取及结果说明 |
| `dmd_model_2d.py` | 双态响应转换与渲染核心保持不变 |
| `coherent_imaging_2d.py`、`textbook_dense_lines_aerial_image.py` | 完整文件保持不变 |

默认运行完成 53 项检查（原基础自检 6 项，现有测试文件 47 项），覆盖独立三角曲线工作点及曝光量等价性、实际 6 μm 基准、无效输入与非对称失败、原复振幅/解析/采样检查。另行执行的开关验收检查共同参考、s=1 路径一致性和生产传播次数。只有满足各项明确数值判据才标记 `PASS`。

`verification/` 集中保存简短报告、必要复现工具及少量修改前基线证据；用于复查固定比例兼容、原实验回归和只开曝光量/只开相位/全部关闭的调度行为，不作为主程序运行依赖，也不继续堆放历史图片和重复日志。验证文件也可单独运行：

```bash
python test_leakage_validation.py --output-dir check_results
```

`verification/REPORT.md` 汇总本轮实际命令、数值判据和结果。目录中的文件各有明确用途：

| 材料 | 用途 |
|---|---|
| `round2_baseline/` | 修改前重新运行取得的数值、截面和来源哈希，供回归比较 |
| `round2_regression.py`、`capture_original_baseline.py` | 复现旧实验、两种兼容调用与原始光学输出不变检查 |
| `verify_run_switches.py` | 在内存中切换开关，检查产物、传播次数和跨路径一致性，不改源文件 |
| `round2_regression_results.json`、`switch_checks.json` | 上述真实运行的精简机器可读证据 |

这些文件用于开发验收；日常运行主程序时无需打开它们。复现命令见 `REPORT.md`。

## 实验适用边界

模型近似所选通道内的 ON/OFF 响应均匀、静态、完全相干，且单微镜空间响应成比例。普通成像衍射、OFF 残余复场与其他路径的杂散光需分别理解。本轮没有新增绝对功率/时间或材料剂量标定、胶内传播、膜厚反应、显影、参数拟合、OPC/ILT；也没有改变原光学传播模型。

目标 CD 工作点是一次名义设定，不能证明真实设备能够打印 6 μm；0.19325954 和 0.5 均不是通用材料阈值。尺寸控制余量还需结合设计边缘 NILS、暗区检查与曝光量扰动结果判断。后续应固定材料和工艺条件，用 CD—剂量实验校准，再用未参与校准的图形验证。
