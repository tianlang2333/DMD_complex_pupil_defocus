"""回归验收辅助：仅在内存中替换main开关，产品源文件不发生变化。
Usage: MPLBACKEND=Agg python verification/verify_run_switches.py SOURCE_DIR OUTPUT_DIR MODE
MODE: default / legacy / phase-only / dose-only / disabled / cross-only
"""
from __future__ import annotations
import ast
import csv
import hashlib
import importlib
import json
import math
import re
from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np

source_dir = Path(sys.argv[1]).resolve()
output_dir = Path(sys.argv[2]).resolve()
mode = sys.argv[3]
assert mode in {'default','legacy','phase-only','dose-only','disabled','cross-only'}
output_dir.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(source_dir))
v = importlib.import_module('run_dmd_2d_validation')
source_file = source_dir / 'run_dmd_2d_validation.py'
source_sha = hashlib.sha256(source_file.read_bytes()).hexdigest()
flags = dict.fromkeys(('run_textbook_validation','run_na_experiment','run_sampling_experiment',
    'run_original_cross','run_convergence','run_leakage_sweep','run_phase_sweep',
    'run_dose_check','run_cross_leakage'), False)
if mode == 'default':
    flags.update(run_leakage_sweep=True, run_phase_sweep=True, run_dose_check=True)
elif mode == 'legacy':
    for key in ('run_textbook_validation','run_na_experiment','run_sampling_experiment',
                'run_original_cross','run_convergence'):
        flags[key] = True
elif mode == 'phase-only':
    flags['run_phase_sweep'] = True
    flags['run_dose_check'] = False
elif mode == 'dose-only':
    flags['run_dose_check'] = True
elif mode == 'cross-only':
    flags['run_cross_leakage'] = True
parsed = ast.parse(source_file.read_text(encoding='utf-8'), filename=str(source_file))
main = next(node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
found = []
for node in ast.walk(main):
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        if name in flags:
            if name == 'run_dose_check':
                assert isinstance(node.value, ast.Constant) and node.value.value is True, (
                    'main must enable run_dose_check by default.'
                )
            node.value = ast.copy_location(ast.Constant(flags[name]), node.value)
            found.append(name)
assert set(found) == set(flags), (found, flags)
exec(compile(ast.fix_missing_locations(ast.Module(body=[main], type_ignores=[])),
             filename=str(source_file), mode='exec'), v.__dict__)

legacy_calls = []
def forbidden_legacy(*args, **kwargs):
    legacy_calls.append('called')
    raise AssertionError('Disabled legacy experiment performed computation.')

stale = {}
if mode != 'legacy':
    for name in ('_make_base_image','run_textbook_cross_validation','run_na_sweep',
                 'run_sampling_ratio_experiment','run_cross_pattern_experiment','run_convergence_check',
                 'run_cross_leakage_comparison'):
        if not (mode == 'cross-only' and name == 'run_cross_leakage_comparison'):
            setattr(v, name, forbidden_legacy)
    # 模拟已有旧结果：应原样保留但不得计入本次运行清单。
    stale_names = ['figure_05_na_sweep.png','validation_metrics.csv']
    for flag, name in (('run_leakage_sweep', 'figure_leakage_ratio.png'),
                       ('run_phase_sweep', 'figure_leakage_phase.png'),
                       ('run_dose_check', 'figure_leakage_dose.png')):
        if not flags[flag]:
            stale_names.append(name)
    if mode == 'disabled':
        stale_names += ['leakage_metrics.csv','leakage_representative_data.npz']
    for name in stale_names:
        marker = ('STALE OUTPUT SENTINEL: '+name).encode()
        (output_dir / name).write_bytes(marker)
        stale[name] = hashlib.sha256(marker).hexdigest()
original_leakage = v.run_leakage_experiments
leakage_propagation_count = []
cache_input_checks = []
def checked_leakage(*args, **kwargs):
    if mode in {'disabled','legacy','cross-only'}:
        assert not kwargs['run_ratio_sweep'] and not kwargs['run_phase_sweep'] and not kwargs['run_dose_check']
        with patch.object(v, 'render_dmd_field', side_effect=AssertionError('Disabled leakage calculated field.')), \
             patch.object(v, 'calculate_coherent_aerial_image_2d', side_effect=AssertionError('Disabled leakage propagated field.')):
            result = original_leakage(*args, **kwargs)
        assert result == ([], {}, [], [])
        leakage_propagation_count.append(0)
        return result
    assert kwargs['run_ratio_sweep'] is (mode == 'default')
    assert kwargs['threshold_mode'] == 'target_cd', 'main must explicitly select target_cd.'
    if mode == 'phase-only':
        assert kwargs['run_phase_sweep'] and not kwargs['run_dose_check']
    elif mode == 'dose-only':
        assert kwargs['run_dose_check'] and not kwargs['run_phase_sweep']
        assert tuple(kwargs['dose_scales']) == (0.95, 1.0, 1.05)
        # bool True与整数1在字典键比较时相等，缓存命中前仍须验证输入。
        invalid_keywords = dict(kwargs, on_intensity_scale=True,
                                off_to_on_intensity_ratio=0.0, off_relative_phase_rad=0.0)
        with patch.object(v, 'plot_dose_comparison',
                          side_effect=AssertionError('Invalid response reached plotting.')):
            try:
                original_leakage(*args, **invalid_keywords)
            except ValueError as error:
                assert 'on_intensity_scale' in str(error), str(error)
            else:
                raise AssertionError('eta=True bypassed validation through baseline cache key.')
        cache_input_checks.append('eta_true_rho_zero_rejected_before_cache_reuse')
    else:
        assert mode == 'default'
        assert kwargs['run_phase_sweep'] and kwargs['run_dose_check']
    with patch.object(v, 'calculate_coherent_aerial_image_2d', wraps=v.calculate_coherent_aerial_image_2d) as propagation:
        result = original_leakage(*args, **kwargs)
        count = propagation.call_count
    leakage_propagation_count.append(count)
    expected_count = {'phase-only': 4, 'dose-only': 2, 'default': 6}[mode]
    assert count == expected_count, (
        f'{mode}: expected {expected_count} production propagations, got {count}'
    )
    return result
v.run_leakage_experiments = checked_leakage
sys.argv = [str(source_file), '--output-dir', str(output_dir)]
v.main()
assert source_sha == hashlib.sha256(source_file.read_bytes()).hexdigest(), 'Source changed during test.'
summary = (output_dir/'validation_summary.txt').read_text(encoding='utf-8')
manifest = summary.split('本次生成文件\n')[-1].splitlines()
check_section = summary.split('一、内部数值自检\n', 1)[1].split('\n二、', 1)[0]
check_lines = [line for line in check_section.splitlines() if line.startswith('- ')]
assert check_lines and all(line.startswith('- PASS:') for line in check_lines), check_lines
data_checks = []
for name, sha in stale.items():
    assert hashlib.sha256((output_dir/name).read_bytes()).hexdigest() == sha
    assert name not in manifest, name
if mode in {'default', 'phase-only', 'dose-only'}:
    with (output_dir/'leakage_metrics.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    assert len({row['reference_intensity'] for row in rows}) == 1
    assert len({row['nominal_threshold_intensity'] for row in rows}) == 1
    assert len({row['nominal_threshold_fraction'] for row in rows}) == 1
    assert all(row['reference_group'] == 'periodic_lines' for row in rows)
    for row in rows:
        assert row['threshold_mode'] == 'target_cd'
        assert math.isclose(float(row['nominal_baseline_cd_um']), float(row['target_cd_um']),
                            rel_tol=0, abs_tol=1e-8)
        assert math.isclose(float(row['threshold_intensity']),
                            float(row['nominal_threshold_intensity']) / float(row['dose_scale']),
                            rel_tol=1e-12, abs_tol=1e-12)
        if row['experiment'] == 'dose':
            paired_baseline = next(candidate for candidate in rows
                                   if candidate['experiment'] == 'dose'
                                   and candidate['dose_state'] == 'baseline'
                                   and candidate['dose_scale'] == row['dose_scale'])
            same_dose_cd = float(paired_baseline['fixed_cd_um'])
            same_dose_status = paired_baseline['threshold_status']
        else:
            same_dose_cd = float(row['nominal_baseline_cd_um'])
            same_dose_status = row['nominal_baseline_status']
        assert row['same_dose_baseline_status'] == same_dose_status
        assert math.isclose(float(row['same_dose_baseline_cd_um']), same_dose_cd,
                            rel_tol=1e-12, abs_tol=1e-12)
        for key, expected in (
                ('delta_cd_to_nominal_baseline_um',
                 float(row['fixed_cd_um']) - float(row['nominal_baseline_cd_um'])),
                ('delta_cd_to_baseline_um',
                 float(row['fixed_cd_um']) - float(row['nominal_baseline_cd_um'])),
                ('delta_cd_to_same_dose_baseline_um', float(row['fixed_cd_um']) - same_dose_cd)):
            assert math.isclose(float(row[key]), expected, rel_tol=1e-12, abs_tol=1e-12), (
                row['case_name'], key, row[key], expected)
    data_checks.extend(['common_nominal_reference', 'effective_threshold_T0_over_s',
                        'nominal_and_same_dose_cd_deltas', 'same_dose_baseline_status'])
    expected_files = {'leakage_metrics.csv', 'leakage_representative_data.npz', 'validation_summary.txt'}
    if mode == 'default':
        expected_files.update(f'figure_leakage_{group}.png' for group in ('ratio', 'phase', 'dose'))
        assert '- leakage_ratio: EXECUTED' in summary
    else:
        assert '- leakage_ratio: NOT RUN' in summary
        expected_files.add('figure_leakage_phase.png' if mode == 'phase-only' else 'figure_leakage_dose.png')
    assert set(manifest) == expected_files, manifest
    if mode == 'phase-only':
        assert len(rows) == 3
        assert all(row['experiment'] == 'phase' for row in rows)
        assert '- leakage_phase: EXECUTED' in summary
        assert '- dose_check: NOT RUN' in summary
    else:
        if mode == 'dose-only':
            assert len(rows) == 6
            assert all(row['experiment'] == 'dose' for row in rows)
            assert '- leakage_phase: NOT RUN' in summary
        else:
            assert len(rows) == 13
            assert [sum(row['experiment'] == group for row in rows)
                    for group in ('ratio', 'phase', 'dose')] == [4, 3, 6]
            assert '- leakage_phase: EXECUTED' in summary
        assert '- dose_check: EXECUTED' in summary
        for state in ('baseline', 'representative'):
            state_rows = [row for row in rows if row['experiment'] == 'dose' and row['dose_state'] == state]
            assert len(state_rows) == 3
            assert {row['case_name'] for row in state_rows} == {
                f'dose_{state}_{index:02d}' for index in range(3)
            }
            assert {float(row['dose_scale']) for row in state_rows} == {0.95, 1.0, 1.05}
            for key in ('on_center_intensity', 'off_center_intensity', 'center_contrast',
                        'design_edge_nils', 'dark_max_intensity'):
                assert len({row[key] for row in state_rows}) == 1, (
                    state, key, [row[key] for row in state_rows])
            if mode == 'default':
                nominal = next(row for row in state_rows if float(row['dose_scale']) == 1.0)
                scan = next(row for row in rows if row['experiment'] == 'ratio'
                            and all(float(row[key]) == float(nominal[key]) for key in (
                                'on_intensity_scale', 'off_to_on_intensity_ratio', 'off_relative_phase_rad')))
                for key in ('fixed_left_edge_um', 'fixed_right_edge_um', 'fixed_cd_um',
                            'cd_error_to_design_um', 'design_edge_nils', 'dark_max_intensity'):
                    assert math.isclose(float(nominal[key]), float(scan[key]), rel_tol=1e-12, abs_tol=1e-12), (
                        state, key, nominal[key], scan[key]
                    )
        data_checks.append('dose_preserves_raw_centers_contrast_nils_darkmax')
        if mode == 'default':
            data_checks.append('dose_s1_matches_response_scan')
elif mode == 'disabled':
    assert manifest == ['validation_summary.txt'], manifest
    assert all(f'- {name}: NOT RUN' in summary for name in (
        'textbook_validation','na_sweep','sampling_ratio','original_cross','legacy_convergence',
        'leakage_ratio','leakage_phase','dose_check','leakage_cross'))
elif mode == 'cross-only':
    assert set(manifest) == {'figure_leakage_cross.png','leakage_representative_data.npz','validation_summary.txt'}, manifest
    assert '- leakage_cross: EXECUTED' in summary
    assert '- leakage_phase: NOT RUN' in summary
    assert '- leakage_ratio: NOT RUN' in summary
    assert '- dose_check: NOT RUN' in summary
else:
    assert len(manifest) == 9, manifest
    assert all((output_dir/f'figure_0{index}_{suffix}.png').exists() for index, suffix in (
        (1,'dmd_state_and_aperture'),(2,'spectrum_pupil_filtered_spectrum'),
        (3,'aerial_image_and_profiles'),(4,'1d_2d_cross_validation'),(5,'na_sweep'),
        (6,'sampling_ratio_comparison'),(7,'2d_cross_pattern')))
if 'leakage_representative_data.npz' in manifest:
    with np.load(output_dir/'leakage_representative_data.npz', allow_pickle=False) as data:
        field_keys = [key for key in data.files if 'image_field' in key]
        assert field_keys and all(np.iscomplexobj(data[key]) for key in field_keys), field_keys
        data_checks.append('npz_retains_complex_fields')
        if mode in {'default', 'dose-only'}:
            assert not any(re.fullmatch(r'dose_.+_\d+_raw_profile', key) for key in data.files)
            for state in ('baseline', 'representative'):
                profile_key = str(data[f'dose_{state}_profile_key'].item())
                assert profile_key in data.files, (state, profile_key)
                profile = data[profile_key]
                assert profile.shape == data['x_um'].shape and np.isrealobj(profile)
                assert np.all(np.isfinite(profile))
                if state == 'baseline':
                    assert profile_key == 'baseline_raw_profile'
                    field_profile = data['baseline_image_field_center_row']
                else:
                    center_row = int(np.argmin(np.abs(data['representative_y_um'])))
                    field_profile = data['representative_image_field'][center_row]
                assert np.allclose(profile, np.abs(field_profile)**2, rtol=1e-12, atol=1e-12)
            assert np.allclose(data['dose_effective_thresholds'],
                               data['nominal_threshold_intensity']/data['dose_scales'],
                               rtol=1e-12, atol=1e-12)
            data_checks.extend(['dose_npz_profiles_reused_without_per_s_copies',
                                'dose_npz_profile_keys_resolve_to_field_intensity'])
# 可选十字的交付目录只保留真实产物；测试用旧文件标记验收后清理。
if mode == 'cross-only':
    for name in stale:
        (output_dir/name).unlink()
report = {'mode':mode, 'status':'PASS', 'source_sha256':source_sha, 'flags':flags,
          'self_checks': {'passed':len(check_lines), 'total':len(check_lines)},
          'data_checks': data_checks,
          'cache_input_checks': cache_input_checks,
          'legacy_disabled_guard_calls':len(legacy_calls),
          'leakage_propagations':leakage_propagation_count,
          'stale_files_unchanged_excluded':list(stale), 'generated_manifest':manifest}
(output_dir/'switch_check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('[Switch gate] PASS:',mode)
