# 开发流程与质量门槛

## 1. 使用方式与风险分级

本流程约束证据质量，不要求每次大重构、引入框架或跑所有耗时实验。用户给出自然语言需求即可；开发者负责填补可从仓库和上下文核实的记录。

- R0：拼写、链接、纯说明或记录调整，且不改变物理定义、默认值和运行方式。核对来源、链接、diff及文档一致性即可
- R1：入口、配置、扫描、绘图、输出格式或一般修复。执行受影响测试、主入口冒烟、配置/输出兼容检查；由非作者或独立审阅过程复核
- R2：传播、单位/符号、几何、阈值/参考、CD/EPE/NILS、采样/窗口、基线或影响数值的依赖修改。增加独立解析参照、采样/视场验证和三视角评审；相关旧回归必须执行

按最高影响定级，不按代码行数。文档若重新定义模型也属于R2。纯规范新增可按R0处理，但涉及现有物理定义的陈述必须与源码核对。无法判断时先按较高风险记录。

探索模式可做最小实验验证想法，但必须标明“探索、未发布”，隔离输出，不覆盖基线。发布模式才允许作可交付结论，必须满足本次适用门槛。未测、失败或暂缓项须列出原因、影响和下一步；核心正确性/科学含义缺陷不以免责声明放行。

## 2. 工程位置、需求冻结与基线

规范和`development_logs/`放在Git仓库根；仿真代码可位于嵌套目录。当前交付ZIP是扁平工程，目标仓库可能采用`DMD_complex_pupil_defocus/dmd_complex_pupil_defocus`层级，不据此硬编码路径。先读取实际树，找到与README、requirements.txt、experiment_scan.py配套的`run_dmd_2d_validation.py`，将其父目录记为`PROJECT_ROOT`；Git顶层记为`REPO_ROOT`。若找到多个候选，按任务分支/源码身份选择并记录，不直接取搜索结果第一个。

所有Python命令先`cd "$PROJECT_ROOT"`，Git身份/diff与根级规范检查使用`REPO_ROOT`。跨目录链接按实际布局核实。交付记录必须保存这两个目录及对应源码身份；示例中的项目文件名均相对于`PROJECT_ROOT`。

1. 摘要记录需求来源、目的、输入/输出、单位、保留行为、不做项、判定通过的数值/行为标准。标准在看结果前确定，未有设备容差时只设置数值验证标准并解释依据
2. 查看 `git status --short`、`git branch --show-current`、`git rev-parse HEAD`；记录仓库URL、基线commit、脏文件归属。尚未有Git checkout时记录来源文件/包及SHA，明确不是已同步的仓库
3. 检查README、原理说明、相关测试和历史限制；先运行相关基线测试，或说明为何不能运行。已有失败、缺失fixture单列，禁止为“全绿”新造历史数据
4. 建立本次需求版本；需求变化时增补记录，说明哪些测试/结论失效。普通明确需求无需等形式化签字，只有关键歧义或授权缺口需要用户决定
5. 保留旧基线及用户文件。数值基线更新单独说明理由、前后差异和批准依据；不能用新实现自动生成的答案作为唯一正确性证明

## 3. 实施与验证

先用最小变更闭合需求，再按风险扩展。新物理、调度、测量和展示尽量保持职责清晰，但不为形式强制迁移旧代码。兼容性变化记录参数、输出字段、默认值和迁移方法。

验证分三层，不能相互代替：

- 解析/独立参照：FFT逆变换和Parseval、已知频率平面波的复场相位、离焦公式独立计算、简单二值轮廓的CD/EPE或已知函数导数。独立参照不能调用被测函数生成期望值；生产路径互相比对只证明一致性
- 数值与回归：历史固定工况、新需求代表/极端工况、非法输入、零强度/无交点、NaN状态、剂量不重复缩放、窗口及采样敏感性。除CD外检查复场、原始I、能量、EPE/NILS及状态中与改动相关的量
- 集成与使用：单工况/扫描、显示与保存开关、去重和参考补算、CSV/JSON字段、输出文件清单、实际入口。GUI mock只能证明调用，不可写成Windows/PyCharm人工验证

R2收敛报告固定物理图形、比较参考和探针；分别改变dx与FOV，记录参照不是无限真值。受资源限制时缩小明确的验收范围或保持探索状态，不写“完全收敛”。

### 当前可用命令目录

从 `run_dmd_2d_validation.py` 所在目录运行，Python环境/依赖按README。以下是可执行模板，不代表已经执行。每次用新输出目录，保留每条命令的起止UTC、cwd、完整参数、环境版本、退出码和stdout/stderr路径。不要只保存终端截图或统计“通过数”。不要把管道末端tee的退出码当测试退出码；Bash可用 `set -o pipefail`。

```bash
cd "$PROJECT_ROOT"  # 先按上节设置为核实过的实际工程目录
export MPLBACKEND=Agg PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR=/tmp/dmd_mpl XDG_CACHE_HOME=/tmp/dmd_cache
OUT=/tmp/dmd_check_$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p "$OUT"
python test_projection_lens_2d.py --report "$OUT/lens.json"
python test_leakage_validation.py --output-dir "$OUT/leakage"
python test_unified_scan.py --report "$OUT/unified.json"
python verify_numerical_reliability.py --output-dir "$OUT/reliability"
python run_dmd_2d_validation.py --no-show --output-dir "$OUT/single"
python run_dmd_2d_validation.py --scan --no-show --output-dir "$OUT/scan"
python verify_run_switches.py . "$OUT/old_only" defocus-only
python verify_run_switches.py . "$OUT/old_combined" combined "$OUT/old_only"
python verify_run_switches.py . "$OUT/old_disabled" defocus-disabled
git -C "$REPO_ROOT" diff --check
```

以上命令示例不会自动保存日志或逐条退出码；执行者应按本节要求重定向/记录，每条单独确认结果，不能仅以最后一条命令成功作为整组通过。

R0不必运行这些仿真；R1选择相关脚本并记录排除理由；R2跑相关物理/回归和可靠性脚本，必要时增补新范围。`verify_run_switches.py`测试的是`legacy_main()`，不替代新入口；`round2_regression.py`所需`round2_baseline/`在当前交付源中缺失，不可声称通过。所有失败需定位并修复后重跑受影响项；若最终源码再改，先前测试不能直接冒充最终测试。

## 4. 三视角评审与缺陷闭环

小团队允许一人兼多角色；必须记录谁/哪个独立评审过程审了哪份源码快照及范围。自动化代理评审应明确其身份，不伪称资质工程师签章。R2至少由独立于作者的审阅过程覆盖：

- 软件工程：需求范围、接口/边界输入、状态和异常、回归、依赖、可复现性、缓存键和产物、最小变更、交付可运行
- 光学：场/强度、单位、FFT/频率/坐标、完整复瞳、离焦符号/近似适用域、倍率、能量和独立解析参照
- 光刻：设计与实际几何、参考和剂量、图形探针、CD/EPE/NILS口径、失效工况、数值误差与设备/工艺精度区分

每条缺陷记录ID、严重性、证据位置、影响、修复/不修复理由、复测证据、复审状态。阻塞：错误物理、虚假验证、数据丢失或不能复现核心结果；重要：可用性/兼容性/局部边界问题；建议：非必要改善。阻塞和影响本次目标的重要缺陷必须闭环后发布；剩余问题由负责人明确接受并限制用途。

## 5. 文档、交付与发布

原理文档说明公式、变量、模型边界和评价含义；README说明安装、单次/扫描运行、日常参数、输出解释和常见失败；字段文档说明单位/参考/NaN；变更记录说明行为变化。少量图必须读得清单位、坐标、共同色标、阈值和探针，不能只为曲线“好看”改变参考。

交付前：

1. 检查diff，只打包必要源码、依赖说明、文档、代表数据和证据；不要打包缓存、凭据、全部大数组或无关用户文件
2. 将运行源码的相对路径/大小/SHA256写入清单。清单排除自身；最终ZIP SHA在ZIP外提供，不能给尚未生成的包伪造hash。Git commit标识与文件/包SHA各有用途，勿混用
3. 在新目录解包/checkout复现适用测试，核对清单和路径；文档专用补丁可只做适用结构/链接检查，不冒充仿真重测
4. 保存待提交diff（含新文件；普通`git diff`不含未跟踪文件）及基线，确保用户能查到改了什么。不要用`git add -A`吞掉未确认归属的文件
5. 有授权才commit/push/建PR；没有就交付本地包并明确未推送。若创建PR，默认draft，除非用户另有要求
6. 发布后读取远端目标分支/commit，核对目标SHA并查看该SHA对应CI；pending/未配置/未运行不是PASS。已推送与已合并/部署分别报告
7. 回滚计划优先恢复到已知基线或通过审查的revert；保留结果和故障证据。不自动force-push、reset用户工作区或删除数据，回滚行动仍受授权约束

## 6. 最小记录

见 [记录目录说明](development_logs/README.md)。R0可以仅写数条简记，按实际产物附diff/清单，不机械创建空证据目录。一次任务可只用一份RECORD.md加diff、必要证据及SHA清单。每次结束写明完成/待决、失败/未测、交付位置和发布状态，避免把未闭环事项埋在聊天历史里。
