# 开发记录

每次有意义的任务使用 `YYYYMMDDTHHMMSSZ_short-task-name/`，UTC时间防止时区混淆。建议从 `_template/RECORD.md`复制；低风险任务可精简，但必须写真实状态。记录应进入版本控制，原始大数组按需要另存并注明可访问位置与hash。

最小目录：

- `RECORD.md`：需求、基线、范围、评审、测试、限制、发布状态
- `changes.patch`：本次待交付变更，含新增文件；不递归包含自身
- `source_manifest.sha256`：明确范围的源码/文档哈希，排除清单自身和依赖它的递归产物
- `evidence/`：实际命令/退出码、必要日志和小型结果；没有执行时不创建假日志

patch不包含自身、最终manifest或记录末尾追加的发布状态时，必须在RECORD中明确排除范围，并使用最终manifest/远端commit补齐身份。ZIP hash放包外。记录自己的最终Git commit只能在后续日志/外部交付回执中引用，不能反复修改本commit中的文件试图自引用。

评审前草稿可缺少最终hash，但发布前应补全适用清单。未形成Git仓库时“来源基线包”和“最终仓库HEAD”分列，不能把包内声明的旧commit当当前远端。
